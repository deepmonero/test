import { memo, SVGProps } from 'react';

const Ellipse2Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 54 120' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M1.31002 120C29.5977 120 53.5747 93.2771 53.5747 60.3133C53.5747 27.3495 28.3433 -0.000103306 0.0556641 -0.000103306'
      stroke='url(#paint0_radial_95_123)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.31002 120C29.5977 120 53.5747 93.2771 53.5747 60.3133C53.5747 27.3495 28.3433 -0.000103306 0.0556641 -0.000103306'
      stroke='url(#paint1_radial_95_123)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.31002 120C29.5977 120 53.5747 93.2771 53.5747 60.3133C53.5747 27.3495 28.3433 -0.000103306 0.0556641 -0.000103306'
      stroke='url(#paint2_radial_95_123)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.31002 120C29.5977 120 53.5747 93.2771 53.5747 60.3133C53.5747 27.3495 28.3433 -0.000103306 0.0556641 -0.000103306'
      stroke='url(#paint3_radial_95_123)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.31002 120C29.5977 120 53.5747 93.2771 53.5747 60.3133C53.5747 27.3495 28.3433 -0.000103306 0.0556641 -0.000103306'
      stroke='url(#paint4_radial_95_123)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_123'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(59.3238 85.1913) rotate(-126.521) scale(24.0631 10.732)'
      >
        <stop stopColor='#0A0505' />
        <stop offset={0.302247} stopColor='#721A31' />
        <stop offset={0.989583} stopColor='#721A31' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_123'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(71.5537 33.2402) rotate(137.954) scale(60.2455 26.8691)'
      >
        <stop stopColor='#FF7070' />
        <stop offset={1} stopColor='#FF7070' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_123'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(45.5259 4.91277) rotate(94.7802) scale(30.1046 13.4265)'
      >
        <stop stopColor='#FF7070' />
        <stop offset={1} stopColor='#FF7070' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_123'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(72.599 38.9893) rotate(143.444) scale(45.8054 39.5012)'
      >
        <stop offset={0.00401228} stopColor='#311288' />
        <stop offset={0.317708} stopColor='#6EF2E6' />
        <stop offset={0.713542} stopColor='#F3F34E' />
        <stop offset={1} stopColor='#CCFFFA' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint4_radial_95_123'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(26.8152 59.9997) rotate(84.1304) scale(56.2179 25.0728)'
      >
        <stop stopColor='#767676' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse2Icon3);
export { Memo as Ellipse2Icon3 };
