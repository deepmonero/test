import { memo, SVGProps } from 'react';

const ChainBlueMarkSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 10 9' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_198)'>
      <path d='M5 9H0L2.5 4.5L0 0H10L7.5 4.5L10 9H5Z' fill='url(#paint0_radial_95_198)' />
    </g>
    <defs>
      <radialGradient
        id='paint0_radial_95_198'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(4.74616 4.51822) rotate(97.3703) scale(5.87853 6.4773)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <clipPath id='clip0_95_198'>
        <rect width={10} height={9} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ChainBlueMarkSvgIcon);
export { Memo as ChainBlueMarkSvgIcon };
