import { memo, SVGProps } from 'react';

const Ellipse6Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 174 200' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M173.17 100.523C173.17 155.463 134.951 200 87.8047 200C40.6586 200 0.696871 154.417 0.696871 99.4777C0.696871 44.538 38.9164 0.000544702 86.0626 0.000544702C133.209 0.000544702 173.17 45.5833 173.17 100.523Z'
      fill='url(#paint0_linear_95_86)'
    />
    <path
      d='M173.17 100.523C173.17 155.463 134.951 200 87.8047 200C40.6586 200 0.696871 154.417 0.696871 99.4777C0.696871 44.538 38.9164 0.000544702 86.0626 0.000544702C133.209 0.000544702 173.17 45.5833 173.17 100.523Z'
      stroke='url(#paint1_radial_95_86)'
      strokeWidth={0.5}
    />
    <path
      d='M173.17 100.523C173.17 155.463 134.951 200 87.8047 200C40.6586 200 0.696871 154.417 0.696871 99.4777C0.696871 44.538 38.9164 0.000544702 86.0626 0.000544702C133.209 0.000544702 173.17 45.5833 173.17 100.523Z'
      stroke='url(#paint2_linear_95_86)'
      strokeOpacity={0.05}
      strokeWidth={0.5}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_86'
        x1={176.175}
        y1={69.3262}
        x2={-49.5964}
        y2={125.297}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#010101' stopOpacity={0} />
        <stop stopOpacity={0.9} />
        <stop offset={0.459707} stopColor='#363636' stopOpacity={0.971584} />
        <stop offset={0.827067} stopColor='#0A0A0A' stopOpacity={0.995031} />
        <stop offset={1} stopColor='#010101' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <radialGradient
        id='paint1_radial_95_86'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(-37.8048 156.621) rotate(-25.9442) scale(129.419 111.607)'
      >
        <stop stopColor='#343434' />
        <stop offset={1} stopColor='#A4A4A4' stopOpacity={0} />
      </radialGradient>
      <linearGradient
        id='paint2_linear_95_86'
        x1={77.1776}
        y1={100}
        x2={267.77}
        y2={185.715}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3E' />
        <stop offset={1} stopColor='#606261' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse6Icon2);
export { Memo as Ellipse6Icon2 };
