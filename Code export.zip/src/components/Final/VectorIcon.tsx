import { memo, SVGProps } from 'react';

const VectorIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 32 87' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.882893 0.694641C0.882893 17.5852 12.7409 32.8767 31.9128 43.9456V86.5573C12.7409 75.4884 0.882893 60.1969 0.882893 43.3064V0.694641Z'
      fill='url(#paint0_linear_95_46)'
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_46'
        x1={37.6549}
        y1={64.4248}
        x2={-15.7529}
        y2={60.8309}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.395627} stopColor='#E0DDDE' />
        <stop offset={0.863744} stopColor='#F9F9F9' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon);
export { Memo as VectorIcon };
