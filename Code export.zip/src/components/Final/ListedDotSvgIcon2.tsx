import { memo, SVGProps } from 'react';

const ListedDotSvgIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 9 9' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_239)'>
      <path
        opacity={0.3}
        d='M4.5 9C6.98528 9 9 6.98528 9 4.5C9 2.01472 6.98528 0 4.5 0C2.01472 0 0 2.01472 0 4.5C0 6.98528 2.01472 9 4.5 9Z'
        fill='#050509'
      />
      <path
        d='M4.5 7C5.88071 7 7 5.88071 7 4.5C7 3.11929 5.88071 2 4.5 2C3.11929 2 2 3.11929 2 4.5C2 5.88071 3.11929 7 4.5 7Z'
        fill='#050509'
      />
    </g>
    <defs>
      <clipPath id='clip0_95_239'>
        <rect width={9} height={9} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ListedDotSvgIcon2);
export { Memo as ListedDotSvgIcon2 };
