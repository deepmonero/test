import { memo, SVGProps } from 'react';

const VectorIcon9 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 36 36' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M18 36C27.9411 36 36 27.9411 36 18C36 8.05887 27.9411 0 18 0C8.05887 0 0 8.05887 0 18C0 27.9411 8.05887 36 18 36Z'
      fill='url(#paint0_linear_95_288)'
    />
    <defs>
      <linearGradient id='paint0_linear_95_288' x1={18} y1={0} x2={18} y2={35.733} gradientUnits='userSpaceOnUse'>
        <stop stopColor='#2AABEE' />
        <stop offset={1} stopColor='#229ED9' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon9);
export { Memo as VectorIcon9 };
