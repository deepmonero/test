import { memo, SVGProps } from 'react';

const BoxIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1268 358' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0 15.5L15.5 0H679.5L696 14.5H1140.5L1156 0H1251.5L1268 14.5V322L1230.5 356.5H359.5L344.5 342H62L46.5 357.5H16L0 342V15.5Z'
      stroke='url(#paint0_radial_95_142)'
      strokeWidth={2}
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_142'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(601.814 179.474) rotate(112.436) scale(250.544 765.477)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(BoxIcon);
export { Memo as BoxIcon };
