import { memo, SVGProps } from 'react';

const YellowIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 23 28' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M10.3733 1.97532C6.55083 2.24387 4.2402 3.74766 3.78514 6.47286C3.52587 8.02555 3.93513 9.75262 4.97822 11.3936C5.92427 12.8986 9.43237 15.0747 9.43237 15.0747C9.43237 15.0747 12.6624 16.5941 14.4283 18.4613C15.8669 19.9824 16.5395 21.1692 15.8954 23.0429C15.1944 25.082 11.9406 25.5065 9.96486 26.0447C15.0552 26.8946 17.0606 25.3474 18.4056 23.9256C19.6437 22.6057 20.0814 20.6039 19.7373 18.9C19.4611 17.5069 17.9825 15.2285 15.9138 13.8017C15.0549 13.2093 12.2294 11.475 12.2294 11.475C11.007 10.646 6.79811 8.14873 7.97466 4.50831C8.46292 2.9976 11.744 2.54832 13.2294 2.25754C13.2294 2.25754 11.4607 1.96221 10.3733 1.97532Z'
      fill='url(#paint0_radial_95_34)'
    />
    <path
      d='M17.483 6.00553C15.6527 7.2864 16.3119 10.1504 18.5252 10.52C20.7676 10.8944 22.2779 8.4825 20.9436 6.61333C20.0946 5.42387 18.6093 5.17586 17.483 6.00553Z'
      fill='url(#paint1_radial_95_34)'
    />
    <path
      d='M17.483 6.00553C15.6527 7.2864 16.3119 10.1504 18.5252 10.52C20.7676 10.8944 22.2779 8.4825 20.9436 6.61333C20.0946 5.42387 18.6093 5.17586 17.483 6.00553Z'
      fill='url(#paint2_radial_95_34)'
    />
    <path
      d='M1.96641 17.7239C0.320558 18.9757 1.00899 21.665 3.04752 22.0054C5.26565 22.3458 6.80502 20.1184 5.53868 18.3803C4.743 17.2297 2.99568 16.9379 1.96641 17.7239Z'
      fill='url(#paint3_radial_95_34)'
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_34'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(11.2624 14.0459) rotate(-85.5561) scale(15.6068 11.8197)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_34'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(18.8137 8.00782) rotate(-87.1695) scale(3.28062 3.26792)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_34'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(18.8137 8.00782) rotate(-87.1695) scale(3.28062 3.26792)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_34'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(3.39258 19.6472) rotate(-87.4646) scale(3.09727 3.21961)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(YellowIcon);
export { Memo as YellowIcon };
