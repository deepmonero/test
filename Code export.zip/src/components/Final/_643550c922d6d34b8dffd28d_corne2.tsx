import { memo, SVGProps } from 'react';

const _643550c922d6d34b8dffd28d_corne2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 15 15' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_193)'>
      <path
        d='M1 15V5.41421C1 5.149 1.10536 4.89464 1.29289 4.70711L4.70711 1.29289C4.89464 1.10536 5.149 1 5.41421 1H15'
        stroke='#EFEFE5'
      />
    </g>
    <defs>
      <clipPath id='clip0_95_193'>
        <rect width={15} height={15} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_643550c922d6d34b8dffd28d_corne2);
export { Memo as _643550c922d6d34b8dffd28d_corne2 };
