import { memo, SVGProps } from 'react';

const _643550c922d6d3e0dcffd28b_icoIn2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 5 6' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_151)'>
      <path
        opacity={0.35}
        d='M0.0967183 3.1982C-0.0322395 3.09659 -0.0322395 2.90341 0.0967183 2.8018L4.58089 0.0565375C4.76952 -0.0920827 5.04344 0.0735937 4.99417 0.306501L4.43538 2.94823C4.42815 2.98238 4.42815 3.01762 4.43538 3.05177L4.99417 5.6935C5.04344 5.92641 4.76952 6.09208 4.58089 5.94346L0.0967183 3.1982Z'
        fill='#EFEFE5'
      />
    </g>
    <defs>
      <clipPath id='clip0_95_151'>
        <rect width={5} height={6} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_643550c922d6d3e0dcffd28b_icoIn2);
export { Memo as _643550c922d6d3e0dcffd28b_icoIn2 };
