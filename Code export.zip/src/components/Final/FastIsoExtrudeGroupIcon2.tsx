import { memo, SVGProps } from 'react';

const FastIsoExtrudeGroupIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 231 146' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect
      width={132.409}
      height={132.409}
      rx={66.2044}
      transform='matrix(0.866025 0.5 -0.866025 0.5 115.655 0.263428)'
      fill='#D9D9D9'
    />
    <rect
      width={132.409}
      height={132.409}
      rx={66.2044}
      transform='matrix(0.866025 0.5 -0.866025 0.5 115.655 0.263428)'
      fill='url(#paint0_radial_95_60)'
    />
    <rect
      width={132.409}
      height={132.409}
      rx={66.2044}
      transform='matrix(0.866025 0.5 -0.866025 0.5 115.655 0.263428)'
      fill='url(#paint1_radial_95_60)'
      fillOpacity={0.2}
    />
    <rect
      width={132.409}
      height={132.409}
      rx={66.2044}
      transform='matrix(0.866025 0.5 -0.866025 0.5 115.655 0.263428)'
      fill='url(#paint2_radial_95_60)'
      fillOpacity={0.2}
    />
    <rect
      width={79.3155}
      height={79.3155}
      rx={39.6578}
      transform='matrix(-0.866025 0.5 0.866025 0.5 114.976 26.8421)'
      fill='#D9D9D9'
    />
    <rect
      width={79.3155}
      height={79.3155}
      rx={39.6578}
      transform='matrix(-0.866025 0.5 0.866025 0.5 114.976 26.8421)'
      fill='url(#paint3_radial_95_60)'
    />
    <mask
      id='mask0_95_60'
      style={{
        maskType: 'alpha',
      }}
      maskUnits='userSpaceOnUse'
      x={66}
      y={38}
      width={98}
      height={57}
    >
      <rect
        width={79.3155}
        height={79.3155}
        rx={39.6578}
        transform='matrix(-0.866025 0.5 0.866025 0.5 114.975 26.8423)'
        fill='#D9D9D9'
      />
      <rect
        width={79.3155}
        height={79.3155}
        rx={39.6578}
        transform='matrix(-0.866025 0.5 0.866025 0.5 114.975 26.8423)'
        fill='url(#paint4_radial_95_60)'
      />
    </mask>
    <g mask='url(#mask0_95_60)'>
      <g opacity={0.4} filter='url(#filter0_f_95_60)'>
        <rect
          width={31.5922}
          height={25.6901}
          rx={12.8451}
          transform='matrix(0.866025 0.5 -0.866025 0.5 110.438 54.6168)'
          fill='url(#paint5_radial_95_60)'
        />
      </g>
      <g opacity={0.5} filter='url(#filter1_f_95_60)'>
        <rect
          width={15.1523}
          height={12.3216}
          rx={6.16078}
          transform='matrix(0.866025 0.5 -0.866025 0.5 113.902 62.7571)'
          fill='#F8CF61'
        />
      </g>
      <g filter='url(#filter2_f_95_60)'>
        <path
          fillRule='evenodd'
          clipRule='evenodd'
          d='M160.985 55.9297C140.182 42.8721 106.453 42.8721 85.6498 55.9297V42.2895C106.453 29.2319 140.182 29.2319 160.985 42.2895V55.9297ZM176.672 79.7502C176.672 70.4938 170.677 62.1137 160.985 56.0477V42.3731C170.677 48.4391 176.672 56.8192 176.672 66.0757V79.7502ZM85.6497 56.0477C75.9576 62.1137 69.9629 70.4938 69.9629 79.7502V66.0757C69.9629 56.8192 75.9576 48.4391 85.6497 42.3731V56.0477Z'
          fill='#A6A4A3'
        />
      </g>
      <path
        d='M163.753 73.5518C163.753 65.0936 158.276 57.4361 149.419 51.8932V39.3978C158.276 44.9408 163.753 52.5982 163.753 61.0564V73.5518Z'
        fill='#93AAFC'
      />
      <path
        d='M163.753 73.5518C163.753 65.0936 158.276 57.4361 149.419 51.8932V39.3978C158.276 44.9408 163.753 52.5982 163.753 61.0564V73.5518Z'
        fill='url(#paint6_linear_95_60)'
      />
      <path
        d='M149.419 51.7851C130.41 39.8535 99.5896 39.8535 80.5803 51.7851V39.3212C99.5896 27.3896 130.41 27.3896 149.419 39.3212V51.7851Z'
        fill='#6580E1'
      />
      <path
        d='M149.419 51.7851C130.41 39.8535 99.5896 39.8535 80.5803 51.7851V39.3212C99.5896 27.3896 130.41 27.3896 149.419 39.3212V51.7851Z'
        fill='#BEB9B6'
      />
      <path
        d='M149.419 51.7851C130.41 39.8535 99.5896 39.8535 80.5803 51.7851V39.3212C99.5896 27.3896 130.41 27.3896 149.419 39.3212V51.7851Z'
        fill='url(#paint7_radial_95_60)'
        fillOpacity={0.2}
      />
      <path
        d='M66.2463 73.5518C66.2463 65.0936 71.724 57.4361 80.5803 51.8932V39.3978C71.724 44.9408 66.2463 52.5982 66.2463 61.0564V73.5518Z'
        fill='#6580E1'
      />
      <path
        d='M66.2463 73.5518C66.2463 65.0936 71.724 57.4361 80.5803 51.8932V39.3978C71.724 44.9408 66.2463 52.5982 66.2463 61.0564V73.5518Z'
        fill='url(#paint8_linear_95_60)'
      />
    </g>
    <path
      d='M34.572 66.4681C34.572 79.3954 43.6475 91.0988 58.3208 99.5704V131.399C43.6475 122.928 34.572 111.224 34.572 98.2972V66.4681Z'
      fill='#93AAFC'
    />
    <path
      d='M34.572 66.4681C34.572 79.3954 43.6475 91.0988 58.3208 99.5704V131.399C43.6475 122.928 34.572 111.224 34.572 98.2972V66.4681Z'
      fill='url(#paint9_linear_95_60)'
    />
    <path
      d='M58.3211 99.5699C89.9862 117.852 141.325 117.852 172.991 99.5699V131.399C141.325 149.681 89.9862 149.681 58.3211 131.399V99.5699Z'
      fill='#6580E1'
    />
    <path
      d='M58.3211 99.5699C89.9862 117.852 141.325 117.852 172.991 99.5699V131.399C141.325 149.681 89.9862 149.681 58.3211 131.399V99.5699Z'
      fill='#BEB9B6'
    />
    <path
      d='M196.739 66.4681C196.739 79.3954 187.664 91.0988 172.99 99.5704V131.399C187.664 122.928 196.739 111.224 196.739 98.2972V66.4681Z'
      fill='#6580E1'
    />
    <path
      d='M196.739 66.4681C196.739 79.3954 187.664 91.0988 172.99 99.5704V131.399C187.664 122.928 196.739 111.224 196.739 98.2972V66.4681Z'
      fill='url(#paint10_linear_95_60)'
    />
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M34.572 66.4684C34.572 79.3956 43.6476 91.099 58.3208 99.5706V131.4C43.6476 122.928 34.572 111.225 34.572 98.2974V66.4684ZM172.991 131.399C187.663 122.928 196.739 111.224 196.739 98.2974V66.4684C196.739 79.3956 187.663 91.099 172.99 99.5706V99.5712C141.325 117.853 89.986 117.852 58.3212 99.5707V131.4C89.9863 149.682 141.326 149.682 172.991 131.4V131.399Z'
      fill='url(#paint11_radial_95_60)'
    />
    <g
      style={{
        mixBlendMode: 'color',
      }}
      opacity={0.4}
      filter='url(#filter3_f_95_60)'
    >
      <rect
        width={103.461}
        height={101.169}
        rx={50.5847}
        transform='matrix(0.988461 0.151474 -0.988461 0.151474 115.637 57.0935)'
        fill='url(#paint12_radial_95_60)'
      />
    </g>
    <defs>
      <filter
        id='filter0_f_95_60'
        x={-32.7099}
        y={-69.0368}
        width={291.407}
        height={275.948}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={63.7079} result='effect1_foregroundBlur_95_60' />
      </filter>
      <filter
        id='filter1_f_95_60'
        x={66.357}
        y={24.5616}
        width={97.5423}
        height={90.1281}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={20} result='effect1_foregroundBlur_95_60' />
      </filter>
      <filter
        id='filter2_f_95_60'
        x={10.9629}
        y={-26.5037}
        width={224.709}
        height={165.254}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={29.5} result='effect1_foregroundBlur_95_60' />
      </filter>
      <filter
        id='filter3_f_95_60'
        x={-255.075}
        y={-238.418}
        width={743.689}
        height={622.019}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={150} result='effect1_foregroundBlur_95_60' />
      </filter>
      <radialGradient
        id='paint0_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(119.202 13.1738) rotate(137.424) scale(162.903 244.063)'
      >
        <stop stopColor='#D6D2CE' />
        <stop offset={0.432292} stopColor='#D9D9D9' />
        <stop offset={1} stopColor='#F1F1F1' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(119.47 12.9486) rotate(124.48) scale(80.2863 84.7207)'
      >
        <stop stopOpacity={0.34} />
        <stop offset={1} stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(1.26924 77.5296) rotate(4.56961) scale(121.648 80.572)'
      >
        <stop stopColor='white' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(71.4042 7.89134) rotate(137.424) scale(97.5821 146.199)'
      >
        <stop stopColor='#D6D2CE' />
        <stop offset={0.432292} stopColor='#D9D9D9' />
        <stop offset={1} stopColor='#F1F1F1' />
      </radialGradient>
      <radialGradient
        id='paint4_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(71.4042 7.89134) rotate(137.424) scale(97.5821 146.199)'
      >
        <stop stopColor='#D6D2CE' />
        <stop offset={0.432292} stopColor='#D9D9D9' />
        <stop offset={1} stopColor='#F1F1F1' />
      </radialGradient>
      <radialGradient
        id='paint5_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(14.9942 12.8971) rotate(98.1471) scale(16.8111 20.4255)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <linearGradient
        id='paint6_linear_95_60'
        x1={164.103}
        y1={59.7575}
        x2={149.111}
        y2={59.6774}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#E3E1E2' />
        <stop offset={1} stopColor='#C0BAB9' />
      </linearGradient>
      <radialGradient
        id='paint7_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(108.769 24.4863) rotate(81.4962) scale(14.6634 47.3286)'
      >
        <stop />
        <stop offset={1} stopOpacity={0} />
      </radialGradient>
      <linearGradient
        id='paint8_linear_95_60'
        x1={80.5688}
        y1={51.7921}
        x2={58.4964}
        y2={56.7948}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.273587} stopColor='#BEB9B6' />
        <stop offset={1} stopColor='#DDDADB' />
      </linearGradient>
      <linearGradient
        id='paint9_linear_95_60'
        x1={34.5911}
        y1={107.836}
        x2={71.5957}
        y2={100.527}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.273587} stopColor='#BEB9B6' />
        <stop offset={1} stopColor='#DDDADB' />
      </linearGradient>
      <linearGradient
        id='paint10_linear_95_60'
        x1={173.009}
        y1={107.836}
        x2={210.014}
        y2={100.527}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.273587} stopColor='#BEB9B6' />
        <stop offset={1} stopColor='#DDDADB' />
      </linearGradient>
      <radialGradient
        id='paint11_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(115.658 91.0321) rotate(90) scale(59.0912 151.115)'
      >
        <stop offset={0.436971} stopColor='#D9D9D9' stopOpacity={0} />
        <stop offset={0.829586} stopColor='#ECC467' />
      </radialGradient>
      <radialGradient
        id='paint12_radial_95_60'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(49.1042 50.7895) rotate(96.7892) scale(65.9977 67.0991)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(FastIsoExtrudeGroupIcon2);
export { Memo as FastIsoExtrudeGroupIcon2 };
