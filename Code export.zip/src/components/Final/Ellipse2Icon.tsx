import { memo, SVGProps } from 'react';

const Ellipse2Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 23 48' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M1.32425 48.0008C12.6393 48.0008 22.2301 37.3118 22.2301 24.1263C22.2301 10.9408 12.1376 0.00093908 0.822514 0.00093908'
      stroke='url(#paint0_radial_95_30)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.32425 48.0008C12.6393 48.0008 22.2301 37.3118 22.2301 24.1263C22.2301 10.9408 12.1376 0.00093908 0.822514 0.00093908'
      stroke='url(#paint1_radial_95_30)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.32425 48.0008C12.6393 48.0008 22.2301 37.3118 22.2301 24.1263C22.2301 10.9408 12.1376 0.00093908 0.822514 0.00093908'
      stroke='url(#paint2_radial_95_30)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.32425 48.0008C12.6393 48.0008 22.2301 37.3118 22.2301 24.1263C22.2301 10.9408 12.1376 0.00093908 0.822514 0.00093908'
      stroke='url(#paint3_radial_95_30)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <path
      d='M1.32425 48.0008C12.6393 48.0008 22.2301 37.3118 22.2301 24.1263C22.2301 10.9408 12.1376 0.00093908 0.822514 0.00093908'
      stroke='url(#paint4_radial_95_30)'
      strokeOpacity={0.9}
      strokeWidth={14}
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_30'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(24.5298 34.0775) rotate(-126.521) scale(9.62524 4.29279)'
      >
        <stop stopColor='#0A0505' />
        <stop offset={0.302247} stopColor='#721A31' />
        <stop offset={0.989583} stopColor='#721A31' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_30'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(29.4217 13.2971) rotate(137.954) scale(24.0982 10.7476)'
      >
        <stop stopColor='#FF7070' />
        <stop offset={1} stopColor='#FF7070' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_30'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(19.0106 1.96609) rotate(94.7802) scale(12.0419 5.37058)'
      >
        <stop stopColor='#FF7070' />
        <stop offset={1} stopColor='#FF7070' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_30'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(29.8399 15.5967) rotate(143.444) scale(18.3222 15.8005)'
      >
        <stop offset={0.00401228} stopColor='#311288' />
        <stop offset={0.317708} stopColor='#6EF2E6' />
        <stop offset={0.713542} stopColor='#F3F34E' />
        <stop offset={1} stopColor='#CCFFFA' stopOpacity={0} />
      </radialGradient>
      <radialGradient
        id='paint4_radial_95_30'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(11.5263 24.0009) rotate(84.1304) scale(22.4872 10.0291)'
      >
        <stop stopColor='#767676' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse2Icon);
export { Memo as Ellipse2Icon };
