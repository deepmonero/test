import { memo, SVGProps } from 'react';

const Group12846Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 325 134' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M324.496 0V101.723L292.89 133.33H0.981201'
      stroke='white'
      strokeWidth={0.932686}
      strokeDasharray='4.66 4.66'
    />
    <path d='M324.419 116.199V133.374H307.244L324.419 116.199Z' fill='white' />
  </svg>
);

const Memo = memo(Group12846Icon);
export { Memo as Group12846Icon };
