import { memo, SVGProps } from 'react';

const MaskGroupIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 270 156' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <mask
      id='mask0_95_50'
      style={{
        maskType: 'alpha',
      }}
      maskUnits='userSpaceOnUse'
      x={39}
      y={22}
      width={192}
      height={111}
    >
      <rect
        width={155.626}
        height={155.626}
        rx={77.8131}
        transform='matrix(0.866025 0.5 -0.866025 0.5 134.995 0.127563)'
        fill='#ABA4A0'
      />
    </mask>
    <g mask='url(#mask0_95_50)'>
      <path
        d='M231.317 91.5399C231.317 76.2888 220.632 62.4816 203.357 52.4871V29.9566C220.632 39.9511 231.317 53.7583 231.317 69.0094V91.5399Z'
        fill='url(#paint0_radial_95_50)'
      />
      <path
        d='M203.357 52.6076C165.973 31.0124 105.363 31.0124 67.9796 52.6076V30.049C105.363 8.45384 165.973 8.45384 203.357 30.049V52.6076Z'
        fill='url(#paint1_radial_95_50)'
      />
      <path
        d='M40.0201 91.5399C40.0201 76.2888 50.705 62.4816 67.9803 52.4871V29.9566C50.705 39.9511 40.0201 53.7583 40.0201 69.0094V91.5399Z'
        fill='url(#paint2_radial_95_50)'
      />
      <g filter='url(#filter0_f_95_50)'>
        <rect
          width={138.504}
          height={138.504}
          rx={69.2521}
          transform='matrix(0.866025 0.5 -0.866025 0.5 142.232 26.8732)'
          fill='url(#paint3_radial_95_50)'
        />
      </g>
      <g filter='url(#filter1_f_95_50)'>
        <rect
          width={125.901}
          height={125.901}
          rx={62.9503}
          transform='matrix(0.866025 0.5 -0.866025 0.5 139.842 21.8585)'
          fill='url(#paint4_radial_95_50)'
        />
      </g>
    </g>
    <defs>
      <filter
        id='filter0_f_95_50'
        x={-320.426}
        y={-330.685}
        width={925.316}
        height={853.621}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={188.921} result='effect1_foregroundBlur_95_50' />
      </filter>
      <filter
        id='filter1_f_95_50'
        x={-126.177}
        y={-148.625}
        width={532.038}
        height={466.867}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={94.4604} result='effect1_foregroundBlur_95_50' />
      </filter>
      <radialGradient
        id='paint0_radial_95_50'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(218.046 60.6236) rotate(-86.9744) scale(39.9477 18.2361)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_50'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(139.104 33.1517) rotate(-67.8706) scale(27.1008 81.905)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_50'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(54.7099 60.6236) rotate(-86.9744) scale(39.9477 18.2361)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_50'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(65.7364 69.5325) rotate(96.6402) scale(90.3253 89.854)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint4_radial_95_50'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(59.7545 63.2052) rotate(96.6402) scale(82.1058 81.6774)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(MaskGroupIcon);
export { Memo as MaskGroupIcon };
