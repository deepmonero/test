import { memo, SVGProps } from 'react';

const VectorIcon6 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 44 97' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M43.842 0.954102C43.842 24.5854 27.2516 45.9796 0.428497 61.4659V96.3766C27.2516 80.8902 43.842 59.4961 43.842 35.8648V0.954102Z'
      fill='#6580E1'
    />
    <path
      d='M43.842 0.954102C43.842 24.5854 27.2516 45.9796 0.428497 61.4659V96.3766C27.2516 80.8902 43.842 59.4961 43.842 35.8648V0.954102Z'
      fill='url(#paint0_linear_95_59)'
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_59'
        x1={0.463443}
        y1={61.7482}
        x2={66.7469}
        y2={45.4626}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.273587} stopColor='#BEB9B6' />
        <stop offset={1} stopColor='#DDDADB' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon6);
export { Memo as VectorIcon6 };
