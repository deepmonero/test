import { memo, SVGProps } from 'react';

const Ellipse3Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 94 110' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M93.6718 55.4906C93.6718 85.1236 73.0573 109.146 47.6279 109.146C22.1986 109.146 0.0171914 83.9326 0.0171914 54.2997C0.0171914 24.6667 20.6317 0.644445 46.0611 0.644445C71.4904 0.644445 93.6718 25.8577 93.6718 55.4906Z'
      fill='#0A0C0E'
      fillOpacity={0.1}
    />
    <path
      d='M93.6718 55.4906C93.6718 85.1236 73.0573 109.146 47.6279 109.146C22.1986 109.146 0.0171914 83.9326 0.0171914 54.2997C0.0171914 24.6667 20.6317 0.644445 46.0611 0.644445C71.4904 0.644445 93.6718 25.8577 93.6718 55.4906Z'
      stroke='url(#paint0_linear_95_126)'
      strokeOpacity={0.15}
    />
    <path
      d='M93.6718 55.4906C93.6718 85.1236 73.0573 109.146 47.6279 109.146C22.1986 109.146 0.0171914 83.9326 0.0171914 54.2997C0.0171914 24.6667 20.6317 0.644445 46.0611 0.644445C71.4904 0.644445 93.6718 25.8577 93.6718 55.4906Z'
      stroke='url(#paint1_linear_95_126)'
      strokeOpacity={0.25}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_126'
        x1={-46.3938}
        y1={-1.55067}
        x2={78.9465}
        y2={37.5902}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#58CBC2' stopOpacity={0.25} />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <linearGradient
        id='paint1_linear_95_126'
        x1={122.107}
        y1={69.1111}
        x2={42.6471}
        y2={47.2256}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3B' />
        <stop offset={1} stopColor='#EBEBEB' stopOpacity={0.33} />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon3);
export { Memo as Ellipse3Icon3 };
