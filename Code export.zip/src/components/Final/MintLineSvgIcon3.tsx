import { memo, SVGProps } from 'react';

const MintLineSvgIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 297 261' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_206)'>
      <path d='M296.786 0V199.063L247.102 260.914H149' stroke='white' strokeWidth={2} strokeDasharray='4.66 4.66' />
      <path d='M296.665 227.389V260.999H269.666L296.665 227.389Z' fill='white' />
    </g>
    <defs>
      <clipPath id='clip0_95_206'>
        <rect width={297} height={261} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(MintLineSvgIcon3);
export { Memo as MintLineSvgIcon3 };
