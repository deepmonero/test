import { memo, SVGProps } from 'react';

const VectorIcon7 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 26 24' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M20.3807 0.221226H24.3164L15.718 10.0486L25.8333 23.4215H17.9131L11.7097 15.3109L4.61161 23.4215H0.673504L9.87034 12.91L0.166667 0.221226H8.28796L13.8953 7.63461L20.3807 0.221226ZM18.9994 21.0658H21.1802L7.10296 2.45321H4.76271L18.9994 21.0658Z'
      fill='white'
    />
  </svg>
);

const Memo = memo(VectorIcon7);
export { Memo as VectorIcon7 };
