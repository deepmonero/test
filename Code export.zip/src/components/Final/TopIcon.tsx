import { memo, SVGProps } from 'react';

const TopIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 55 7' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M7 1H0L6 7H12.5L7 1Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M22 0.5H15L21 6.5H27.5L22 0.5Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M36 0.5H29L35 6.5H41.5L36 0.5Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M49 0.5H42L48 6.5H54.5L49 0.5Z' fill='#D9D9D9' stroke='#D9D9D9' />
  </svg>
);

const Memo = memo(TopIcon);
export { Memo as TopIcon };
