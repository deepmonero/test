import { memo, SVGProps } from 'react';

const VectorIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 32 87' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M31.6354 0.694641C31.6354 17.5852 19.7774 32.8767 0.60553 43.9456V86.5573C19.7774 75.4884 31.6354 60.1969 31.6354 43.3064V0.694641Z'
      fill='url(#paint0_linear_95_48)'
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_48'
        x1={0.630507}
        y1={55.3982}
        x2={49.0234}
        y2={45.9536}
        gradientUnits='userSpaceOnUse'
      >
        <stop offset={0.273587} stopColor='#BEB9B6' />
        <stop offset={1} stopColor='#DDDADB' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon3);
export { Memo as VectorIcon3 };
