import { memo, SVGProps } from 'react';

const SvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 343 97' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_186)'>
      <path
        d='M16 94.0703H320.191C321.181 94.0703 322.129 93.744 322.829 93.1633L341 78.0703'
        stroke='url(#paint0_radial_95_186)'
        strokeWidth={2.5}
        strokeLinecap='round'
        strokeDasharray='270 270'
      />
      <path
        d='M2 94.0703V23.2212C2 22.2453 2.25743 21.3092 2.71565 20.6191L14.3157 3.14816C14.7739 2.45803 15.3954 2.07031 16.0434 2.07031H340'
        stroke='url(#paint1_radial_95_186)'
        strokeWidth={2.5}
        strokeLinecap='round'
        strokeDasharray='482 482'
      />
    </g>
    <defs>
      <radialGradient
        id='paint0_radial_95_186'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(170.25 86.1027) rotate(157.077) scale(26.6099 82.6763)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_186'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(162.42 48.2565) rotate(113.156) scale(64.8171 202.972)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <clipPath id='clip0_95_186'>
        <rect width={343} height={96} fill='white' transform='translate(0 0.0703125)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(SvgIcon);
export { Memo as SvgIcon };
