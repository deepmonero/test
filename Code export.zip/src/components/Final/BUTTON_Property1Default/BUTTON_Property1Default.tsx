import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './BUTTON_Property1Default.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
  text?: {
    bUYSnmtNOW?: ReactNode;
  };
}
/* @figmaId 30:4861 */
export const BUTTON_Property1Default: FC<Props> = memo(function BUTTON_Property1Default(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.Before}></div>
      <div className={classes.Before2}></div>
      <div className={classes.Before3}></div>
      <div className={classes.After}></div>
      <div className={classes.After2}></div>
      <div className={classes.divBtnPrimaryLines}>
        <div className={classes.divBtnPrimaryText}>
          {props.text?.bUYSnmtNOW != null ? (
            props.text?.bUYSnmtNOW
          ) : (
            <div className={classes.bUYSnmtNOW}>BUY $snmt NOW </div>
          )}
        </div>
        <div className={classes.unnamed}>↑</div>
      </div>
      <div className={classes.After3}></div>
    </div>
  );
});
