import { memo, SVGProps } from 'react';

const TopIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 55 9' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M7 1.19227H0L6 8.34522H12.5L7 1.19227Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M22 0.596327H15L21 7.74927H27.5L22 0.596327Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M36 0.596327H29L35 7.74927H41.5L36 0.596327Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M49 0.596327H42L48 7.74927H54.5L49 0.596327Z' fill='#D9D9D9' stroke='#D9D9D9' />
  </svg>
);

const Memo = memo(TopIcon2);
export { Memo as TopIcon2 };
