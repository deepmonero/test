import { memo, SVGProps } from 'react';

const YellowIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 57 68' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M25.9336 3.93393C16.3775 4.60532 10.6009 8.36479 9.46324 15.1778C8.81506 19.0595 9.83822 23.3772 12.4459 27.4795C14.8111 31.242 23.5813 36.6825 23.5813 36.6825C23.5813 36.6825 31.6563 40.4809 36.0711 45.1489C39.6676 48.9517 41.3492 51.9185 39.7389 56.603C37.9865 61.7007 29.8518 62.7618 24.9125 64.1073C37.6384 66.2323 42.6519 62.3641 46.0143 58.8097C49.1097 55.51 50.2039 50.5053 49.3436 46.2457C48.653 42.7628 44.9566 37.0669 39.7849 33.4999C37.6376 32.0188 30.5739 27.6831 30.5739 27.6831C27.5179 25.6107 16.9956 19.3675 19.937 10.2664C21.1577 6.48963 29.3604 5.36644 33.0739 4.63949C33.0739 4.63949 28.6522 3.90116 25.9336 3.93393Z'
      fill='url(#paint0_radial_95_127)'
    />
    <path
      d='M43.7079 14.0113C39.1322 17.2134 40.7803 24.3734 46.3134 25.2974C51.9194 26.2335 55.6952 20.2037 52.3596 15.5308C50.2369 12.5571 46.5238 11.9371 43.7079 14.0113Z'
      fill='url(#paint1_radial_95_127)'
    />
    <path
      d='M43.7079 14.0113C39.1322 17.2134 40.7803 24.3734 46.3134 25.2974C51.9194 26.2335 55.6952 20.2037 52.3596 15.5308C50.2369 12.5571 46.5238 11.9371 43.7079 14.0113Z'
      fill='url(#paint2_radial_95_127)'
    />
    <path
      d='M4.91584 43.3055C0.801199 46.435 2.52227 53.1581 7.61861 54.0091C13.1639 54.8603 17.0124 49.2916 13.8465 44.9464C11.8573 42.0698 7.48901 41.3404 4.91584 43.3055Z'
      fill='url(#paint3_radial_95_127)'
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_127'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(28.1564 34.1105) rotate(-85.5561) scale(39.0169 29.5492)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_127'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(47.0347 19.017) rotate(-87.1695) scale(8.20154 8.16981)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_127'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(47.0347 19.017) rotate(-87.1695) scale(8.20154 8.16981)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_127'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(8.48125 48.1138) rotate(-87.4646) scale(7.74317 8.04902)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(YellowIcon3);
export { Memo as YellowIcon3 };
