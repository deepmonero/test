import { memo, SVGProps } from 'react';

const MintRightLineSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 186 468' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_210)'>
      <path d='M185.718 467.5V26.136L166.626 1.31165H0' stroke='white' strokeWidth={2} strokeDasharray='4.3 4.3' />
      <path d='M185.718 13.9898V0.499969H175.344L185.718 13.9898Z' fill='white' />
    </g>
    <defs>
      <clipPath id='clip0_95_210'>
        <rect width={186} height={467} fill='white' transform='translate(0 0.499969)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(MintRightLineSvgIcon);
export { Memo as MintRightLineSvgIcon };
