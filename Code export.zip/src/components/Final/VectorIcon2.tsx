import { memo, SVGProps } from 'react';

const VectorIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 151 61' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.346634 0.138062C41.7198 24.0249 108.799 24.0249 150.172 0.138062V42.7498C108.799 66.6366 41.7198 66.6366 0.346634 42.7498V0.138062Z'
      fill='url(#paint0_linear_95_47)'
    />
    <path
      d='M0.346634 0.138062C41.7198 24.0249 108.799 24.0249 150.172 0.138062V42.7498C108.799 66.6366 41.7198 66.6366 0.346634 42.7498V0.138062Z'
      fill='url(#paint1_radial_95_47)'
      fillOpacity={0.2}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_47'
        x1={-3.30592}
        y1={24.584}
        x2={153.24}
        y2={29.5153}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#E3E1E2' />
        <stop offset={1} stopColor='#C0BAB9' />
      </linearGradient>
      <radialGradient
        id='paint1_radial_95_47'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(136.524 99.054) rotate(-129.879) scale(81.7615 205.019)'
      >
        <stop />
        <stop offset={1} stopOpacity={0} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon2);
export { Memo as VectorIcon2 };
