import { memo, SVGProps } from 'react';

const Ellipse3Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 38 44' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M37.4688 22.1964C37.4688 34.0496 29.223 43.6585 19.0512 43.6585C8.8795 43.6585 0.00693989 33.5732 0.00693989 21.72C0.00693989 9.86683 8.25276 0.257923 18.4245 0.257923C28.5962 0.257923 37.4688 10.3432 37.4688 22.1964Z'
      fill='#0A0C0E'
      fillOpacity={0.1}
    />
    <path
      d='M37.4688 22.1964C37.4688 34.0496 29.223 43.6585 19.0512 43.6585C8.8795 43.6585 0.00693989 33.5732 0.00693989 21.72C0.00693989 9.86683 8.25276 0.257923 18.4245 0.257923C28.5962 0.257923 37.4688 10.3432 37.4688 22.1964Z'
      stroke='url(#paint0_linear_95_33)'
      strokeOpacity={0.15}
    />
    <path
      d='M37.4688 22.1964C37.4688 34.0496 29.223 43.6585 19.0512 43.6585C8.8795 43.6585 0.00693989 33.5732 0.00693989 21.72C0.00693989 9.86683 8.25276 0.257923 18.4245 0.257923C28.5962 0.257923 37.4688 10.3432 37.4688 22.1964Z'
      stroke='url(#paint1_linear_95_33)'
      strokeOpacity={0.25}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_33'
        x1={-18.5575}
        y1={-0.620123}
        x2={31.5786}
        y2={15.0362}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#58CBC2' stopOpacity={0.25} />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <linearGradient
        id='paint1_linear_95_33'
        x1={48.843}
        y1={27.6446}
        x2={17.0589}
        y2={18.8904}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3B' />
        <stop offset={1} stopColor='#EBEBEB' stopOpacity={0.33} />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon);
export { Memo as Ellipse3Icon };
