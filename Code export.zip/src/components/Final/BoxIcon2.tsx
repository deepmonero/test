import { memo, SVGProps } from 'react';

const BoxIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1268 304' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0 13.1804L15.5 0H679.5L696 12.3301H1140.5L1156 0H1251.5L1268 12.3301V273.813L1230.5 303.15H359.5L344.5 290.82H62L46.5 304H16L0 290.82V13.1804Z'
      stroke='url(#paint0_radial_95_163)'
      strokeWidth={2}
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_163'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(601.814 152.615) rotate(115.9) scale(218.911 744.982)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(BoxIcon2);
export { Memo as BoxIcon2 };
