import { memo, SVGProps } from 'react';

const Ellipse9Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 16 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={8} cy={9.63168} rx={8} ry={9.53726} fill='url(#paint0_radial_95_164)' />
    <defs>
      <radialGradient
        id='paint0_radial_95_164'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(7.59386 9.6703) rotate(95.5773) scale(12.4147 10.4006)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse9Icon2);
export { Memo as Ellipse9Icon2 };
