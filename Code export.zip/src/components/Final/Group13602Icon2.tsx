import { memo, SVGProps } from 'react';

const Group13602Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 184 49' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 17.2866V0.596368H21.4202' stroke='#F6B60B' strokeWidth={2} />
    <path d='M0.713867 30.4003V48.2826H22.1341' stroke='#F6B60B' strokeWidth={2} />
    <path d='M162.08 48.2826H183.5V30.4003' stroke='#F6B60B' strokeWidth={2} />
    <path d='M163.508 0.596368L183.5 0.596368V18.4787' stroke='#F6B60B' strokeWidth={2} />
  </svg>
);

const Memo = memo(Group13602Icon2);
export { Memo as Group13602Icon2 };
