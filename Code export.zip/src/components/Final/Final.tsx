import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { _61a8f3b83e808a031716e599_plusS2 } from './_61a8f3b83e808a031716e599_plusS2.js';
import { _61a8f3b83e808a031716e599_plusS3 } from './_61a8f3b83e808a031716e599_plusS3.js';
import { _61a8f3b83e808a031716e599_plusS4 } from './_61a8f3b83e808a031716e599_plusS4.js';
import { _61a8f3b83e808a031716e599_plusS5 } from './_61a8f3b83e808a031716e599_plusS5.js';
import { _61a8f3b83e808a031716e599_plusS } from './_61a8f3b83e808a031716e599_plusS.js';
import { _643550c922d6d3e0dcffd28b_icoIn2 } from './_643550c922d6d3e0dcffd28b_icoIn2.js';
import { _643550c922d6d3e0dcffd28b_icoIn } from './_643550c922d6d3e0dcffd28b_icoIn.js';
import { _643550c922d6d34b8dffd28d_corne2 } from './_643550c922d6d34b8dffd28d_corne2.js';
import { _643550c922d6d34b8dffd28d_corne } from './_643550c922d6d34b8dffd28d_corne.js';
import { ArrowRightIcon } from './ArrowRightIcon.js';
import { BgTelegramSvgIcon } from './BgTelegramSvgIcon.js';
import { BoxIcon2 } from './BoxIcon2.js';
import { BoxIcon } from './BoxIcon.js';
import { BUTTON_Property1Default } from './BUTTON_Property1Default/BUTTON_Property1Default.js';
import { ChainBlueMarkSvgIcon2 } from './ChainBlueMarkSvgIcon2.js';
import { ChainBlueMarkSvgIcon } from './ChainBlueMarkSvgIcon.js';
import { DownIcon2 } from './DownIcon2.js';
import { DownIcon } from './DownIcon.js';
import { Ellipse2Icon2 } from './Ellipse2Icon2.js';
import { Ellipse2Icon3 } from './Ellipse2Icon3.js';
import { Ellipse2Icon } from './Ellipse2Icon.js';
import { Ellipse3Icon2 } from './Ellipse3Icon2.js';
import { Ellipse3Icon3 } from './Ellipse3Icon3.js';
import { Ellipse3Icon } from './Ellipse3Icon.js';
import { Ellipse6Icon2 } from './Ellipse6Icon2.js';
import { Ellipse6Icon3 } from './Ellipse6Icon3.js';
import { Ellipse6Icon } from './Ellipse6Icon.js';
import { Ellipse9Icon2 } from './Ellipse9Icon2.js';
import { Ellipse9Icon } from './Ellipse9Icon.js';
import { FastIsoExtrudeGroupIcon2 } from './FastIsoExtrudeGroupIcon2.js';
import { FastIsoExtrudeGroupIcon } from './FastIsoExtrudeGroupIcon.js';
import classes from './Final.module.css';
import { Group118Icon } from './Group118Icon.js';
import { Group12846Icon } from './Group12846Icon.js';
import { Group13602Icon2 } from './Group13602Icon2.js';
import { Group13602Icon } from './Group13602Icon.js';
import { HeroCardBgSvgIcon } from './HeroCardBgSvgIcon.js';
import { ListedCard1SvgIcon } from './ListedCard1SvgIcon.js';
import { ListedCard2SvgIcon } from './ListedCard2SvgIcon.js';
import { ListedDotSvgIcon2 } from './ListedDotSvgIcon2.js';
import { ListedDotSvgIcon3 } from './ListedDotSvgIcon3.js';
import { ListedDotSvgIcon4 } from './ListedDotSvgIcon4.js';
import { ListedDotSvgIcon } from './ListedDotSvgIcon.js';
import { MaskGroupIcon } from './MaskGroupIcon.js';
import { MintLineSvgIcon2 } from './MintLineSvgIcon2.js';
import { MintLineSvgIcon3 } from './MintLineSvgIcon3.js';
import { MintLineSvgIcon } from './MintLineSvgIcon.js';
import { MintRightLineSvgIcon } from './MintRightLineSvgIcon.js';
import { SocialIcons_PlatformTelegramCo } from './SocialIcons_PlatformTelegramCo/SocialIcons_PlatformTelegramCo.js';
import { SocialIcons_PlatformXTwitterCo } from './SocialIcons_PlatformXTwitterCo/SocialIcons_PlatformXTwitterCo.js';
import { SvgIcon2 } from './SvgIcon2.js';
import { SvgIcon } from './SvgIcon.js';
import { TopIcon2 } from './TopIcon2.js';
import { TopIcon } from './TopIcon.js';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon4 } from './VectorIcon4.js';
import { VectorIcon5 } from './VectorIcon5.js';
import { VectorIcon6 } from './VectorIcon6.js';
import { VectorIcon7 } from './VectorIcon7.js';
import { VectorIcon8 } from './VectorIcon8.js';
import { VectorIcon9 } from './VectorIcon9.js';
import { VectorIcon10 } from './VectorIcon10.js';
import { VectorIcon } from './VectorIcon.js';
import { YellowIcon2 } from './YellowIcon2.js';
import { YellowIcon3 } from './YellowIcon3.js';
import { YellowIcon } from './YellowIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 13:2269 */
export const Final: FC<Props> = memo(function Final(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.header}>
        <div className={classes.header2}>
          <div className={classes.divHeaderContainer}>
            <div className={classes.divVerticalLine}></div>
            <div className={classes.divHeaderSidePart}>
              <div className={classes.linkHome}>
                <div className={classes.coin}>
                  <div className={classes.ellipse2}>
                    <Ellipse2Icon className={classes.icon5} />
                  </div>
                  <div className={classes.ellipse6}>
                    <Ellipse6Icon className={classes.icon6} />
                  </div>
                  <div className={classes.ellipse3}>
                    <Ellipse3Icon className={classes.icon7} />
                  </div>
                  <div className={classes.yellow}>
                    <YellowIcon className={classes.icon8} />
                  </div>
                </div>
                <div className={classes.satoshiTokens}>Satoshi Tokens</div>
              </div>
            </div>
            <div className={classes.divVerticalLine2}></div>
          </div>
        </div>
        <div className={classes.frame9}>
          <div className={classes.hEROTEXT}>
            <div className={classes.stepIntoTheSNMTMemeCentral}>
              <p className={classes.labelWrapper}>
                <span className={classes.label}>Step into the </span>
                <span className={classes.label2}>SNMT</span>
                <span className={classes.label3}> Meme Central</span>
              </p>
            </div>
            <div className={classes.whereTheMagicOfSatoshiNakamoto}>
              where the magic of Satoshi Nakamoto Token (SNMT) meets the world of laughter and blockchain. Unleash the
              power of humor with our meme token dedicated to the enigmatic creator of Bitcoin.
            </div>
          </div>
          <div className={classes.bUTTON2}>
            <div className={classes.Before}></div>
            <div className={classes.Before2}></div>
            <div className={classes.Before3}></div>
            <div className={classes.After}></div>
            <div className={classes.divBtnPrimaryLines}>
              <div className={classes.divBtnPrimaryText}>
                <div className={classes.bUYSnmtNOW2}>BUY $snmt NOW </div>
              </div>
              <div className={classes.unnamed}>↑</div>
              <div className={classes.After2}></div>
            </div>
            <div className={classes.After3}></div>
          </div>
        </div>
      </div>
      <div className={classes.originalFace}></div>
      <div className={classes.originalFace2}></div>
      <div className={classes.originalFace3}></div>
      <div className={classes.originalFace4}></div>
      <div className={classes.fastIsoExtrudeGroup}>
        <FastIsoExtrudeGroupIcon className={classes.icon9} />
      </div>
      <div className={classes.originalFace5}></div>
      <div className={classes.originalFace6}></div>
      <div className={classes.originalFace7}></div>
      <div className={classes.leftFace}></div>
      <div className={classes.rightFace}></div>
      <div className={classes.vector}>
        <VectorIcon className={classes.icon10} />
      </div>
      <div className={classes.vector2}>
        <VectorIcon2 className={classes.icon11} />
      </div>
      <div className={classes.vector3}>
        <VectorIcon3 className={classes.icon12} />
      </div>
      <div className={classes.originalFace8}></div>
      <div className={classes.originalFace9}></div>
      <div className={classes.originalFace10}></div>
      <div className={classes.originalFace11}></div>
      <div className={classes.maskGroup}>
        <MaskGroupIcon className={classes.icon13} />
      </div>
      <div className={classes.vector4}>
        <VectorIcon4 className={classes.icon14} />
      </div>
      <div className={classes.vector5}>
        <VectorIcon5 className={classes.icon15} />
      </div>
      <div className={classes.vector6}>
        <VectorIcon6 className={classes.icon16} />
      </div>
      <div className={classes.fastIsoExtrudeGroup2}>
        <FastIsoExtrudeGroupIcon2 className={classes.icon17} />
      </div>
      <div className={classes.cOIN}>
        <div className={classes.ellipse22}>
          <Ellipse2Icon2 className={classes.icon18} />
        </div>
        <div className={classes.ellipse62}>
          <Ellipse6Icon2 className={classes.icon19} />
        </div>
        <div className={classes.ellipse32}>
          <Ellipse3Icon2 className={classes.icon20} />
        </div>
        <div className={classes.yellow2}>
          <YellowIcon2 className={classes.icon21} />
        </div>
      </div>
      <div className={classes.tECHNOLOGY}>
        <div className={classes.card}>
          <div className={classes.heroCardBgSvgFill}>
            <div className={classes.heroCardBgSvg}>
              <HeroCardBgSvgIcon className={classes.icon22} />
            </div>
          </div>
          <div className={classes.heading1}>
            <div className={classes.tECHNOLOGY2}>TECHNOLOGY</div>
          </div>
          <div className={classes.ourTechIsTheHeartbeatOfTheFutu}>
            Our tech is the heartbeat of the future! Satoshi Nakamoto Token is powered by cutting-edge BRC20 wizardry.
          </div>
        </div>
      </div>
      <div className={classes.tOKENOMICS}>
        <div className={classes.cOIM}>
          <div className={classes.ellipse23}>
            <Ellipse2Icon3 className={classes.icon23} />
          </div>
          <div className={classes.ellipse63}>
            <Ellipse6Icon3 className={classes.icon24} />
          </div>
          <div className={classes.ellipse33}>
            <Ellipse3Icon3 className={classes.icon25} />
          </div>
          <div className={classes.yellow3}>
            <YellowIcon3 className={classes.icon26} />
          </div>
        </div>
        <div className={classes.top}>
          <TopIcon className={classes.icon27} />
        </div>
        <div className={classes.down}>
          <DownIcon className={classes.icon28} />
        </div>
        <div className={classes.box}>
          <BoxIcon className={classes.icon29} />
        </div>
        <div className={classes.ellipse9}>
          <Ellipse9Icon className={classes.icon30} />
        </div>
        <div className={classes.tokenomics}>Tokenomics</div>
        <div className={classes.group13602}>
          <Group13602Icon className={classes.icon31} />
        </div>
        <div className={classes.commitmentToAFairlyMintedEcosy}>
          Commitment to a fairly minted ecosystem ensures that every participant has an equal opportunity to engage in
          this groundbreaking tokenomic experience.
        </div>
        <div className={classes.divHeroInfoRight}>
          <div className={classes.divHeroFeature}>
            <div className={classes._643550c922d6d3e0dcffd28b_icoIn}>
              <div className={classes._643550c922d6d3e0dcffd28b_icoIn2}>
                <div className={classes._643550c922d6d3e0dcffd28b_icoIn3}>
                  <_643550c922d6d3e0dcffd28b_icoIn className={classes.icon32} />
                </div>
              </div>
            </div>
            <div className={classes.pParagraph}>
              <div className={classes.satoshiNakamotoToken}>Satoshi Nakamoto Token</div>
            </div>
            <div className={classes.name}>Name</div>
          </div>
          <div className={classes.divHeroFeature2}>
            <div className={classes._643550c922d6d3e0dcffd28b_icoIn4}>
              <div className={classes._643550c922d6d3e0dcffd28b_icoIn5}>
                <div className={classes._643550c922d6d3e0dcffd28b_icoIn6}>
                  <_643550c922d6d3e0dcffd28b_icoIn2 className={classes.icon33} />
                </div>
              </div>
            </div>
            <div className={classes.pParagraph2}>
              <div className={classes._1000000SNMT}>100,000,000 $SNMT</div>
            </div>
            <div className={classes.tokenSupply}>Token Supply</div>
          </div>
          <div className={classes.divHeroFeature3}></div>
        </div>
      </div>
      <div className={classes.connect}>
        <div className={classes.top2}>
          <TopIcon2 className={classes.icon34} />
        </div>
        <div className={classes.down2}>
          <DownIcon2 className={classes.icon35} />
        </div>
        <div className={classes.box2}>
          <BoxIcon2 className={classes.icon36} />
        </div>
        <div className={classes.ellipse92}>
          <Ellipse9Icon2 className={classes.icon37} />
        </div>
        <div className={classes.connect2}>Connect</div>
        <div className={classes.group136022}>
          <Group13602Icon2 className={classes.icon38} />
        </div>
        <div className={classes.connectWithUsVia}>Connect with us via:</div>
        <div className={classes.connectWithUsForTheLatestUpdat}>
          Connect with us for the latest updates and community engagement! Follow our social media channels, join the
          conversation on telegram and stay informed about upcoming events and developments. Your participation is key
          to our shared journey. Let&#39;s shape the future together!
        </div>
        <div className={classes.divColXl8}>
          <div className={classes.divFlexWrap}>
            <div className={classes.linkBgTwitterSvg}>
              <div className={classes.bgTwitterSvgFill}>
                <div className={classes.bgTwitterSvg}>
                  <div className={classes.group118}>
                    <Group118Icon className={classes.icon39} />
                  </div>
                  <SocialIcons_PlatformXTwitterCo
                    className={classes.socialIcons}
                    swap={{
                      vector: <VectorIcon7 className={classes.icon} />,
                    }}
                  />
                </div>
              </div>
            </div>
            <div className={classes.linkBgTelegramSvg}>
              <div className={classes.bgTelegramSvgFill}>
                <div className={classes.bgTelegramSvg}>
                  <BgTelegramSvgIcon className={classes.icon40} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.divFormBlock4}>
          <div className={classes.formEmailForm2}>
            <div className={classes.input}>
              <div className={classes.enterYourEMail}>Enter Your e-mail</div>
            </div>
            <BUTTON_Property1Default
              className={classes.bUTTON}
              text={{
                bUYSnmtNOW: <div className={classes.bUYSnmtNOW}>SUBSCRIBE NOW</div>,
              }}
            />
          </div>
        </div>
      </div>
      <div className={classes.scroll}>
        <div className={classes.bottomLeft}>
          <div className={classes.kNOWMORE}>KNOW MORE </div>
          <div className={classes.highlight}>
            <div className={classes.heading}>
              <div className={classes.details}>
                <div className={classes.heading12}>
                  <div className={classes.aBOUTUS}>ABOUT US</div>
                </div>
                <div className={classes.sVG}>
                  <SvgIcon className={classes.icon41} />
                </div>
                <div className={classes.line}></div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.bottomRight}>
          <div className={classes.link}>
            <div className={classes.scroll2}>
              <div className={classes.text}>
                <div className={classes.sCROLL}>SCROLL</div>
              </div>
            </div>
            <div className={classes.button}>
              <div className={classes.buttonScroll}>
                <div className={classes.file}>
                  <div className={classes.svg}>
                    <SvgIcon2 className={classes.icon42} />
                  </div>
                </div>
              </div>
              <div className={classes.corner}>
                <div className={classes._643550c922d6d34b8dffd28d_corne}>
                  <div className={classes._643550c922d6d34b8dffd28d_corne2}>
                    <div className={classes._643550c922d6d34b8dffd28d_corne3}>
                      <_643550c922d6d34b8dffd28d_corne className={classes.icon43} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={classes.corner2}>
                <div className={classes._643550c922d6d34b8dffd28d_corne4}>
                  <div className={classes._643550c922d6d34b8dffd28d_corne5}>
                    <div className={classes._643550c922d6d34b8dffd28d_corne6}>
                      <_643550c922d6d34b8dffd28d_corne2 className={classes.icon44} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.aBOUT}>
        <div className={classes.mintLineSvg}>
          <div className={classes.mintLineSvgFill}>
            <div className={classes.mintLineSvg2}>
              <div className={classes.group12846}>
                <Group12846Icon className={classes.icon45} />
              </div>
              <div className={classes.meetTheVisionaries}>Meet the Visionaries</div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.theRevolutionaryMemeTokenInspi}>
        The revolutionary meme token, inspired by the legendary Satoshi Nakamoto! Embrace the spirit of crypto
        innovation with SNMT, a community-driven token that combines humor and blockchain technology. Bringing
        decentralization to the forefront, all in the name of Satoshi Nakamoto. Together, we are rewriting the future of
        meme tokens and celebrating the genius behind the crypto revolution.
      </div>
      <div className={classes.divRowMargin}>
        <div className={classes.divMainProcess}>
          <div className={classes.chainBlueMarkSvg}>
            <div className={classes.chainBlueMarkSvgFill}>
              <div className={classes.chainBlueMarkSvg2}>
                <ChainBlueMarkSvgIcon className={classes.icon46} />
              </div>
            </div>
          </div>
          <div className={classes.pWhiteText}>
            <div className={classes.rOADMAP}>ROADMAP</div>
          </div>
          <div className={classes.chainBlueMarkSvg3}>
            <div className={classes.chainBlueMarkSvgFill2}>
              <div className={classes.chainBlueMarkSvg4}>
                <ChainBlueMarkSvgIcon2 className={classes.icon47} />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.phase1GenesisBuildingFoundatio}>
        <div className={classes.textBlock}> Phase 1: Genesis - Building Foundations (Q4 2023-Q1 2024)</div>
        <div className={classes.textBlock2}>
          <p className={classes.labelWrapper2}>
            <span className={classes.label4}> </span>
            <span className={classes.label5}>
              - Develop and launch the Satoshi Nakamoto Token with a transparent and fair distribution model.
            </span>
          </p>
        </div>
        <div className={classes.textBlock3}>
          {' '}
          - Establish a robust and secure blockchain infrastructure to ensure the token&#39;s stability.
        </div>
        <div className={classes.textBlock4}>
          {' '}
          - Begin community building through social media, forums, and partnerships.
        </div>
      </div>
      <div className={classes.phase2IgnitionCommunityActivat}>
        <div className={classes.textBlock5}>Phase 2: Ignition - Community Activation (Q2 2024)</div>
        <div className={classes.textBlock6}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label6}> </span>
            <span className={classes.label7}>
              - Launch community-driven initiatives, including contests, events, and collaborative projects.
            </span>
          </p>
        </div>
        <div className={classes.textBlock7}>
          {' '}
          - Initiate strategic partnerships to expand the token&#39;s reach and use cases.
        </div>
        <div className={classes.textBlock8}>
          <p></p>
        </div>
        <div className={classes.textBlock9}>
          {' '}
          - SNMT will be integrated to Unisat Swap, enhancing utility and accessibility in the crypto ecosystem.
        </div>
        <div className={classes.textBlock10}>
          {' '}
          - The token aims to use cases in gaming and NFTs, fostering broader adoption and engagement.
        </div>
      </div>
      <div className={classes.phase3ZenithMassAdoptionAndBey}>
        <div className={classes.textBlock11}>Phase 3 : Zenith - Mass Adoption and Beyond (Q3 2024)</div>
        <div className={classes.textBlock12}>
          <p className={classes.labelWrapper4}>
            <span className={classes.label8}>
              {' '}
              - Expand use cases by targeting industries beyond traditional crypto sectors.
            </span>
          </p>
        </div>
        <div className={classes.textBlock13}>
          {' '}
          - Develop partnerships with mainstream businesses to integrate Satoshi Nakamoto Token for everyday
          transactions.
        </div>
        <div className={classes.textBlock14}>
          {' '}
          - Explore interoperability with other blockchains to enhance accessibility and user experience.
        </div>
        <div className={classes.textBlock15}>
          {' '}
          - Engage the community through interactive campaigns, fueling widespread adoption. Making SNMT a cornerstone
          in the decentralized entertainment landscape
        </div>
      </div>
      <div className={classes.mintLineSvg3}>
        <div className={classes.mintLineSvg4}>
          <MintLineSvgIcon2 className={classes.icon48} />
        </div>
      </div>
      <div className={classes.mintLineSvg5}>
        <div className={classes.mintLineSvg6}>
          <MintLineSvgIcon3 className={classes.icon49} />
        </div>
      </div>
      <div className={classes.mintRightLineSvg}>
        <div className={classes.mintRightLineSvgFill}>
          <div className={classes.mintRightLineSvg2}>
            <MintRightLineSvgIcon className={classes.icon50} />
          </div>
        </div>
      </div>
      <div className={classes.hOWTOBUY}>
        <div className={classes._1}>
          <div className={classes.divColMd12}>
            <div className={classes.tEXT}>
              <div className={classes.heading2}>
                <div className={classes.hOWTOBUYSNMT}>
                  <p className={classes.labelWrapper5}>
                    <span className={classes.label9}>HOW TO BUY </span>
                    <span className={classes.label10}>$SNMT</span>
                  </p>
                </div>
              </div>
              <div className={classes.purchaseSNMTByNavigatingToASup}>
                Purchase SNMT by navigating to a supported exchange.
              </div>
            </div>
            <div className={classes.divRow}>
              <div className={classes.divColMd122}>
                <div className={classes.divBgCard2}>
                  <div className={classes.listedCard2SvgFill}>
                    <div className={classes.listedCard2Svg}>
                      <ListedCard2SvgIcon className={classes.icon51} />
                    </div>
                  </div>
                  <div className={classes.heading4}>
                    <div className={classes.bUYONUNISAT}>BUY ON UNISAT </div>
                    <div className={classes.unnamed2}>↑</div>
                  </div>
                  <div className={classes.divDFlex}></div>
                </div>
              </div>
              <div className={classes.divColMd123}>
                <div className={classes.divBgCard1}>
                  <div className={classes.listedCard1SvgFill}>
                    <div className={classes.listedCard1Svg}>
                      <ListedCard1SvgIcon className={classes.icon52} />
                    </div>
                  </div>
                  <div className={classes.heading42}>
                    <div className={classes.bUYONOKX}>BUY ON OKX</div>
                    <div className={classes.unnamed3}>↑</div>
                  </div>
                  <div className={classes.divDFlex2}></div>
                </div>
              </div>
            </div>
            <div className={classes.mORECOMINGSOON}>MORE COMING SOON...</div>
          </div>
        </div>
      </div>
      <div className={classes.fAQSInteractiveComponent}>
        <div className={classes.frequentlyAskedQuestions}>Frequently Asked Questions</div>
        <div className={classes.q2}>
          <div className={classes.div}>
            <div className={classes.whatAreBRC20Tokens}>What are BRC-20 tokens?</div>
            <div className={classes._61a8f3b83e808a031716e599_plusS}>
              <div className={classes._61a8f3b83e808a031716e599_plusS2}>
                <_61a8f3b83e808a031716e599_plusS className={classes.icon53} />
              </div>
            </div>
          </div>
          <div className={classes.div2}></div>
        </div>
        <div className={classes.q3}>
          <div className={classes.div3}>
            <div className={classes.howDoYouBuyBRC20Tokens}>How do you buy BRC-20 tokens?</div>
            <div className={classes._61a8f3b83e808a031716e599_plusS3}>
              <div className={classes._61a8f3b83e808a031716e599_plusS4}>
                <_61a8f3b83e808a031716e599_plusS2 className={classes.icon54} />
              </div>
            </div>
          </div>
          <div className={classes.div4}></div>
        </div>
        <div className={classes.q4}>
          <div className={classes.div5}>
            <div className={classes.howAreBRC20TokensCreated}>How are BRC-20 tokens created?</div>
            <div className={classes._61a8f3b83e808a031716e599_plusS5}>
              <div className={classes._61a8f3b83e808a031716e599_plusS6}>
                <_61a8f3b83e808a031716e599_plusS3 className={classes.icon55} />
              </div>
            </div>
          </div>
          <div className={classes.div6}></div>
        </div>
        <div className={classes.q5}>
          <div className={classes.div7}>
            <div className={classes.whatSTheDifferenceBetweenBRC20}>
              <div className={classes.textBlock16}>What’s the difference between BRC-20 and ERC-20 tokens?</div>
              <div className={classes.textBlock17}>
                <p></p>
              </div>
            </div>
            <div className={classes._61a8f3b83e808a031716e599_plusS7}>
              <div className={classes._61a8f3b83e808a031716e599_plusS8}>
                <_61a8f3b83e808a031716e599_plusS4 className={classes.icon56} />
              </div>
            </div>
          </div>
          <div className={classes.div8}></div>
        </div>
      </div>
      <div className={classes.frame13604}>
        <SocialIcons_PlatformXTwitterCo
          className={classes.socialIcons2}
          swap={{
            vector: <VectorIcon8 className={classes.icon2} />,
          }}
        />
        <SocialIcons_PlatformTelegramCo
          className={classes.socialIcons3}
          swap={{
            vector: <VectorIcon9 className={classes.icon3} />,
            vector2: <VectorIcon10 className={classes.icon4} />,
          }}
        />
      </div>
      <div className={classes._2023SnmtVipAllRightReserved}>© 2023 snmt.vip. All Right Reserved</div>
    </div>
  );
});
