import { memo, SVGProps } from 'react';

const Ellipse3Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 157 182' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M156.454 91.8182C156.454 141.206 122.096 181.244 79.7138 181.244C37.3315 181.244 0.362486 139.222 0.362486 89.8332C0.362486 40.4449 34.7201 0.407708 77.1024 0.407708C119.485 0.407708 156.454 42.4298 156.454 91.8182Z'
      fill='#0A0C0E'
      fillOpacity={0.1}
    />
    <path
      d='M156.454 91.8182C156.454 141.206 122.096 181.244 79.7138 181.244C37.3315 181.244 0.362486 139.222 0.362486 89.8332C0.362486 40.4449 34.7201 0.407708 77.1024 0.407708C119.485 0.407708 156.454 42.4298 156.454 91.8182Z'
      stroke='url(#paint0_linear_95_87)'
      strokeOpacity={0.15}
    />
    <path
      d='M156.454 91.8182C156.454 141.206 122.096 181.244 79.7138 181.244C37.3315 181.244 0.362486 139.222 0.362486 89.8332C0.362486 40.4449 34.7201 0.407708 77.1024 0.407708C119.485 0.407708 156.454 42.4298 156.454 91.8182Z'
      stroke='url(#paint1_linear_95_87)'
      strokeOpacity={0.25}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_87'
        x1={-76.9893}
        y1={-3.25082}
        x2={131.911}
        y2={61.984}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#58CBC2' stopOpacity={0.25} />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <linearGradient
        id='paint1_linear_95_87'
        x1={203.846}
        y1={114.519}
        x2={71.4124}
        y2={78.0431}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3B' />
        <stop offset={1} stopColor='#EBEBEB' stopOpacity={0.33} />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse3Icon2);
export { Memo as Ellipse3Icon2 };
