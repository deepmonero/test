import { memo, SVGProps } from 'react';

const YellowIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 94 113' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M42.5566 5.88947C26.6297 7.00846 17.0021 13.2742 15.106 24.6293C14.0257 31.0988 15.731 38.2949 20.0772 45.1322C24.019 51.403 38.6361 60.4705 38.6361 60.4705C38.6361 60.4705 52.0945 66.8012 59.4524 74.5812C65.4466 80.9191 68.2494 85.8639 65.5654 93.6714C62.6448 102.167 49.0869 103.936 40.8548 106.178C62.0647 109.72 70.4204 103.273 76.0245 97.3492C81.1834 91.8496 83.0071 83.5085 81.5734 76.4092C80.4224 70.6044 74.2617 61.1112 65.6422 55.1662C62.0632 52.6977 50.2904 45.4714 50.2904 45.4714C45.1971 42.0175 27.66 31.6121 32.5624 16.4436C34.5968 10.149 48.268 8.27699 54.4571 7.06541C54.4571 7.06541 47.0876 5.83485 42.5566 5.88947Z'
      fill='url(#paint0_radial_95_88)'
    />
    <path
      d='M72.1805 22.6849C64.5542 28.0219 67.3011 39.9553 76.5231 41.4952C85.8664 43.0553 92.1593 33.0056 86.5999 25.2174C83.0621 20.2613 76.8737 19.228 72.1805 22.6849Z'
      fill='url(#paint1_radial_95_88)'
    />
    <path
      d='M72.1805 22.6849C64.5542 28.0219 67.3011 39.9553 76.5231 41.4952C85.8664 43.0553 92.1593 33.0056 86.5999 25.2174C83.0621 20.2613 76.8737 19.228 72.1805 22.6849Z'
      fill='url(#paint2_radial_95_88)'
    />
    <path
      d='M7.52692 71.5088C0.669175 76.7246 3.53763 87.9299 12.0315 89.3483C21.2737 90.7668 27.6878 81.4857 22.4114 74.2437C19.096 69.4494 11.8155 68.2337 7.52692 71.5088Z'
      fill='url(#paint3_radial_95_88)'
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_88'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(46.2613 56.1838) rotate(-85.5561) scale(65.0283 49.2487)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_88'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(77.7252 31.0278) rotate(-87.1695) scale(13.6692 13.6164)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_88'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(77.7252 31.0278) rotate(-87.1695) scale(13.6692 13.6164)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_88'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(13.4693 79.5226) rotate(-87.4646) scale(12.9053 13.4151)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.271875} stopColor='#FFBB4C' />
        <stop offset={0.516666} stopColor='#F18914' />
        <stop offset={0.777083} stopColor='#AC5600' />
        <stop offset={1} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(YellowIcon2);
export { Memo as YellowIcon2 };
