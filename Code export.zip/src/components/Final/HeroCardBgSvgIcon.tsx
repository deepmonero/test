import { memo, SVGProps } from 'react';

const HeroCardBgSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 605 140' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_93)'>
      <path
        d='M520.346 139.014H162.652L146.012 125.211V125.069H47.5326V125.211L30.8928 139.014H18.4973L1.68867 125.07V14.9287L18.4961 0.98584H188.634L205.441 14.9277V15.0696H303.923V14.9277L320.73 0.98584H543.504L560.312 14.9287V105.863L520.346 139.014Z'
        stroke='url(#paint0_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        d='M520.346 139.014L560.311 105.863V14.9285L543.504 0.985915H320.73L303.922 14.9274V15.0697H205.441V14.9274L188.634 0.985915H18.4957L1.68856 14.9285V125.07L18.4971 139.014H30.8938L47.5321 125.212V125.07H146.013V125.212L162.652 139.014L520.346 139.014ZM520.346 140L162.16 140L145.35 126.056H48.196L31.3862 140H18.0048L0.5 125.478V14.5202L18.0034 0H189.126L206.105 14.0837H303.259L320.237 0H543.997L561.5 14.5202V106.271L521.127 139.76L520.742 140L520.346 140Z'
        fill='white'
        fillOpacity={0.2}
        stroke='url(#paint1_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        opacity={0.2}
        d='M544.108 110.238L516.771 132.914H370.303'
        stroke='url(#paint2_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        d='M522.096 58.7324L520.143 43.8753L522.096 42.3074L524.049 43.8753L522.096 58.7324ZM522.096 35.232L520.101 33.6173L522.096 18.7324L524.091 33.616L522.096 35.232Z'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M522.096 49.7221L522.79 44.4431L522.096 43.8844L521.402 44.4424L522.096 49.7221ZM522.096 33.6512L522.83 33.0563L522.096 27.5789L521.362 33.057L522.096 33.6512ZM522.097 58.7318H522.094L520.143 43.8786L522.096 42.3068L524.049 43.8793L522.097 58.7318ZM522.096 35.2322L520.101 33.617L522.096 18.7324L524.091 33.6163L522.096 35.2322Z'
        fill='white'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M503.52 38.5688L517.319 36.4664L518.775 38.5688L517.319 40.6712L503.52 38.5688ZM525.347 38.5688L526.847 36.4209L540.672 38.5688L526.848 40.7167L525.347 38.5688Z'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M511.888 38.5685L516.792 39.3154L517.311 38.5682L516.792 37.8219L511.888 38.5685ZM526.815 38.5682L527.368 39.3591L532.455 38.5685L527.367 37.7782L526.815 38.5682ZM503.52 38.5698V38.5666L517.316 36.4661L518.776 38.5682L517.315 40.6713L503.52 38.5698ZM525.347 38.5682L526.847 36.4209L540.672 38.5682L526.848 40.7165L525.347 38.5682Z'
        fill='white'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M508.961 24.0412L520.099 33.0601L519.748 35.6554L517.337 36.0333L508.961 24.0412ZM524.395 40.6585L526.866 40.2815L535.231 52.3254L524.046 43.3199L524.395 40.6585Z'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M514.878 30.4122L517.855 34.6732L518.713 34.5399L518.836 33.6176L514.878 30.4122ZM525.433 41.7758L525.305 42.7558L529.421 46.0698L526.343 41.6374L525.433 41.7758ZM508.96 24.0423L508.962 24.04L520.097 33.0576L519.749 35.6554L517.335 36.0306L508.96 24.0423ZM524.395 40.6579L526.866 40.2817L535.232 52.325L524.046 43.3196L524.395 40.6579Z'
        fill='white'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M535.231 24.0407L526.855 36.0329L524.444 35.6549L524.093 33.0596L535.231 24.0407ZM519.797 40.658L520.147 43.3186L508.961 52.325L517.325 40.2819L519.797 40.658Z'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M529.314 30.4121L525.356 33.6168L525.48 34.5402L526.337 34.6734L529.314 30.4121ZM518.759 41.7762L517.849 41.6376L514.771 46.0697L518.888 42.755L518.759 41.7762ZM535.23 24.0404L535.232 24.0427L526.857 36.0308L524.444 35.6558L524.095 33.0568L535.23 24.0404ZM519.798 40.6583L520.147 43.3188L508.961 52.3254L517.325 40.2819L519.798 40.6583Z'
        fill='white'
        stroke='#E5E5E5'
        strokeWidth={0.985915}
      />
      <path
        d='M135.636 132.754H143.182L150.73 139.014H143.182L135.636 132.754Z'
        stroke='url(#paint3_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        opacity={0.8}
        d='M120.544 132.754H128.09L135.639 139.014H128.09L120.544 132.754Z'
        stroke='url(#paint4_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        opacity={0.65}
        d='M105.093 132.754H112.639L120.188 139.014H112.639L105.093 132.754Z'
        stroke='url(#paint5_radial_95_93)'
        strokeWidth={0.985915}
      />
      <path
        opacity={0.4}
        d='M89.642 132.754H97.1881L104.737 139.014H97.1881L89.642 132.754Z'
        stroke='url(#paint6_radial_95_93)'
        strokeWidth={0.985915}
      />
    </g>
    <defs>
      <radialGradient
        id='paint0_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(266.82 70.2793) rotate(115.228) scale(98.8379 330.053)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint1_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(266.76 70.2834) rotate(115.009) scale(100.071 332.051)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint2_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(452.794 121.622) rotate(131.742) scale(19.6863 84.7001)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint3_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(142.8 135.897) rotate(105.681) scale(4.21154 9.49182)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint4_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(127.708 135.897) rotate(105.681) scale(4.21154 9.49182)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint5_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(112.257 135.897) rotate(105.681) scale(4.21154 9.49182)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <radialGradient
        id='paint6_radial_95_93'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(96.8062 135.897) rotate(105.681) scale(4.21154 9.49182)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <clipPath id='clip0_95_93'>
        <rect width={604} height={140} fill='white' transform='translate(0.5)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(HeroCardBgSvgIcon);
export { Memo as HeroCardBgSvgIcon };
