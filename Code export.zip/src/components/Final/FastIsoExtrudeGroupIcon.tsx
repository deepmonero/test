import { memo, SVGProps } from 'react';

const FastIsoExtrudeGroupIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 484 147' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect width={156.385} height={7.10196} transform='matrix(0.866025 0.5 0 1 31.5591 43.3258)' fill='#93AAFC' />
    <rect width={156.385} height={7.10196} transform='matrix(0.866025 -0.5 0 1 316.818 121.518)' fill='#6580E1' />
    <path
      d='M0.529297 0.0750122C0.529297 16.9655 12.3873 32.2571 31.5592 43.3259V50.4279C12.3873 39.359 0.529297 24.0675 0.529297 7.17697V0.0750122Z'
      fill='#93AAFC'
    />
    <path
      d='M166.993 121.518C208.366 145.405 275.445 145.405 316.819 121.518V128.62C275.445 152.507 208.366 152.507 166.993 128.62V121.518Z'
      fill='#6580E1'
    />
    <path
      d='M483.282 0.0748291C483.282 16.9654 471.424 32.2569 452.252 43.3258V50.4277C471.424 39.3588 483.282 24.0673 483.282 7.17679V0.0748291Z'
      fill='#6580E1'
    />
  </svg>
);

const Memo = memo(FastIsoExtrudeGroupIcon);
export { Memo as FastIsoExtrudeGroupIcon };
