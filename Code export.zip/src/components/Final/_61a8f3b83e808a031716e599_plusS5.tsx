import { memo, SVGProps } from 'react';

const _61a8f3b83e808a031716e599_plusS5 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 18 18' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M9 1.99951V15.9995' stroke='white' strokeWidth={1.99999} strokeLinecap='round' strokeLinejoin='round' />
    <path d='M1.99951 9H15.9995' stroke='white' strokeWidth={1.99999} strokeLinecap='round' strokeLinejoin='round' />
  </svg>
);

const Memo = memo(_61a8f3b83e808a031716e599_plusS5);
export { Memo as _61a8f3b83e808a031716e599_plusS5 };
