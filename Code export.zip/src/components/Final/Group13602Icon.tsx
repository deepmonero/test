import { memo, SVGProps } from 'react';

const Group13602Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 184 40' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 14V0H21.4202' stroke='#F6B60B' strokeWidth={2} />
    <path d='M0.714008 25V40H22.1342' stroke='#F6B60B' strokeWidth={2} />
    <path d='M162.08 40H183.5V25' stroke='#F6B60B' strokeWidth={2} />
    <path d='M163.508 0L183.5 0V15' stroke='#F6B60B' strokeWidth={2} />
  </svg>
);

const Memo = memo(Group13602Icon);
export { Memo as Group13602Icon };
