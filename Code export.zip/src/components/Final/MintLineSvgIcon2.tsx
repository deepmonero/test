import { memo, SVGProps } from 'react';

const MintLineSvgIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 227 117' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_202)'>
      <path
        d='M226.836 0V89.235L188.862 116.962H113.882'
        stroke='#E5E5E5'
        strokeWidth={2}
        strokeDasharray='4.66 4.66'
      />
      <path d='M226.744 101.933V117H206.109L226.744 101.933Z' fill='#E5E5E5' />
    </g>
    <defs>
      <clipPath id='clip0_95_202'>
        <rect width={227} height={117} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(MintLineSvgIcon2);
export { Memo as MintLineSvgIcon2 };
