import { memo, SVGProps } from 'react';

const Ellipse9Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 17 16' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={8.5} cy={8} r={8} fill='url(#paint0_radial_95_143)' />
    <defs>
      <radialGradient
        id='paint0_radial_95_143'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(8.09386 8.03239) rotate(96.6402) scale(10.4344 10.3799)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse9Icon);
export { Memo as Ellipse9Icon };
