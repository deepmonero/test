import { memo, SVGProps } from 'react';

const VectorIcon8 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 34 31' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M26.4894 0.855862H31.5496L20.4946 13.4911L33.5 30.6848H23.3169L15.3411 20.2569L6.21492 30.6848H1.15165L12.9762 17.17L0.5 0.855862H10.9417L18.1511 10.3874L26.4894 0.855862ZM24.7135 27.656H27.5174L9.41809 3.72556H6.40919L24.7135 27.656Z'
      fill='white'
    />
  </svg>
);

const Memo = memo(VectorIcon8);
export { Memo as VectorIcon8 };
