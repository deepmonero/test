import { memo, SVGProps } from 'react';

const Group118Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 85 85' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M51.772 0.99971H9.114L1 9.09971V74.9197L9.115 83.0197H74.885L83.5 74.4197V32.6817L51.772 0.99971Z'
      fill='#050509'
    />
    <path
      d='M51.7723 0.99971L9.1144 1L1 9.10253V74.9226L9.1153 83.026H74.8855L83.5003 74.4229V32.6818L51.7723 0.99971ZM8.70061 0H52.1864L84.5003 32.2672V74.8375L75.2993 84.026H8.70151L0 75.3372V8.68789L8.70061 0Z'
      fill='white'
      fillOpacity={0.2}
    />
    <path d='M83.1 20.0257V0.92571H64L83.1 20.0257Z' fill='url(#paint0_radial_95_170)' />
    <defs>
      <radialGradient
        id='paint0_radial_95_170'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(73.0652 10.5144) rotate(96.6402) scale(12.456 12.391)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(Group118Icon);
export { Memo as Group118Icon };
