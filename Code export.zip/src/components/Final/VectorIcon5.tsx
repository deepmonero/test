import { memo, SVGProps } from 'react';

const VectorIcon5 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 211 61' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.809357 0.465698C58.6941 33.8854 152.544 33.8855 210.428 0.465698V35.3764C152.544 68.7961 58.6941 68.7961 0.809357 35.3764V0.465698Z'
      fill='#6580E1'
    />
    <path
      d='M0.809357 0.465698C58.6941 33.8854 152.544 33.8855 210.428 0.465698V35.3764C152.544 68.7961 58.6941 68.7961 0.809357 35.3764V0.465698Z'
      fill='#BEB9B6'
    />
    <path
      d='M0.809357 0.465698C58.6941 33.8854 152.544 33.8855 210.428 0.465698V35.3764C152.544 68.7961 58.6941 68.7961 0.809357 35.3764V0.465698Z'
      fill='url(#paint0_radial_95_58)'
      fillOpacity={0.2}
    />
    <defs>
      <radialGradient
        id='paint0_radial_95_58'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(124.592 76.9282) rotate(-99.2328) scale(41.1531 143.833)'
      >
        <stop />
        <stop offset={1} stopOpacity={0} />
      </radialGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon5);
export { Memo as VectorIcon5 };
