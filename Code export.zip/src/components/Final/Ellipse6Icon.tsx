import { memo, SVGProps } from 'react';

const Ellipse6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 42 48' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M41.5612 24.1261C41.5612 37.3116 32.3885 48.0006 21.0734 48.0006C9.75836 48.0006 0.167565 37.0608 0.167565 23.8752C0.167565 10.6897 9.34024 0.000740977 20.6553 0.000740977C31.9704 0.000740977 41.5612 10.9406 41.5612 24.1261Z'
      fill='url(#paint0_linear_95_32)'
    />
    <path
      d='M41.5612 24.1261C41.5612 37.3116 32.3885 48.0006 21.0734 48.0006C9.75836 48.0006 0.167565 37.0608 0.167565 23.8752C0.167565 10.6897 9.34024 0.000740977 20.6553 0.000740977C31.9704 0.000740977 41.5612 10.9406 41.5612 24.1261Z'
      stroke='url(#paint1_radial_95_32)'
      strokeWidth={0.5}
    />
    <path
      d='M41.5612 24.1261C41.5612 37.3116 32.3885 48.0006 21.0734 48.0006C9.75836 48.0006 0.167565 37.0608 0.167565 23.8752C0.167565 10.6897 9.34024 0.000740977 20.6553 0.000740977C31.9704 0.000740977 41.5612 10.9406 41.5612 24.1261Z'
      stroke='url(#paint2_linear_95_32)'
      strokeOpacity={0.05}
      strokeWidth={0.5}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_32'
        x1={42.2824}
        y1={16.6389}
        x2={-11.9028}
        y2={30.0719}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#010101' stopOpacity={0} />
        <stop stopOpacity={0.9} />
        <stop offset={0.459707} stopColor='#363636' stopOpacity={0.971584} />
        <stop offset={0.827067} stopColor='#0A0A0A' stopOpacity={0.995031} />
        <stop offset={1} stopColor='#010101' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <radialGradient
        id='paint1_radial_95_32'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(-9.07283 37.5895) rotate(-25.9442) scale(31.0605 26.7856)'
      >
        <stop stopColor='#343434' />
        <stop offset={1} stopColor='#A4A4A4' stopOpacity={0} />
      </radialGradient>
      <linearGradient
        id='paint2_linear_95_32'
        x1={18.5229}
        y1={24.0007}
        x2={64.2649}
        y2={44.572}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3E' />
        <stop offset={1} stopColor='#606261' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse6Icon);
export { Memo as Ellipse6Icon };
