import { memo, SVGProps } from 'react';

const MintLineSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 297 168' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_117)'>
      <path
        d='M296.786 0V128.132L247.102 167.945H149'
        stroke='white'
        strokeWidth={0.932686}
        strokeDasharray='4.66 4.66'
      />
      <path d='M296.665 146.365V168H269.666L296.665 146.365Z' fill='white' />
    </g>
    <defs>
      <clipPath id='clip0_95_117'>
        <rect width={297} height={168} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(MintLineSvgIcon);
export { Memo as MintLineSvgIcon };
