import { memo, SVGProps } from 'react';

const BgTelegramSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 85 85' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_95_177)'>
      <path
        d='M51.772 1.002H9.114L1 9.102V74.922L9.115 83.022H74.885L83.5 74.422V32.684L51.772 1.002Z'
        fill='#050509'
      />
      <path
        d='M51.7723 1.002L9.1144 1.00229L1 9.10482V74.9249L9.1153 83.0283H74.8855L83.5003 74.4252V32.6841L51.7723 1.002ZM8.70061 0.00228992H52.1864L84.5003 32.2695V74.8398L75.2993 84.0283H8.70151L0 75.3395V8.69018L8.70061 0.00228992Z'
        fill='white'
        fillOpacity={0.2}
      />
      <path d='M83.1 20.028V0.928H64L83.1 20.028Z' fill='url(#paint0_radial_95_177)' />
      <path
        d='M42.281 54.49C39.852 54.49 37.4776 53.7697 35.458 52.4203C33.4384 51.0708 31.8644 49.1528 30.9348 46.9087C30.0053 44.6647 29.7621 42.1954 30.236 39.8131C30.7098 37.4308 31.8795 35.2426 33.597 33.525C35.3146 31.8075 37.5028 30.6378 39.8851 30.164C42.2674 29.6901 44.7367 29.9333 46.9807 30.8628C49.2248 31.7924 51.1428 33.3664 52.4923 35.386C53.8417 37.4056 54.562 39.78 54.562 42.209C54.562 45.4661 53.2681 48.5898 50.965 50.893C48.6618 53.1961 45.5381 54.49 42.281 54.49ZM38.461 43.646L38.477 43.637L39.545 47.162C39.683 47.544 39.872 47.613 40.101 47.581C40.2979 47.5432 40.475 47.4369 40.601 47.281L42.06 45.871L45.2 48.189C45.772 48.505 46.184 48.341 46.326 47.658L48.361 38.052C48.586 37.158 48.193 36.799 47.499 37.084L35.542 41.703C34.727 42.03 34.731 42.487 35.395 42.689L38.462 43.647L38.461 43.646Z'
        fill='#E5E5E5'
      />
    </g>
    <defs>
      <radialGradient
        id='paint0_radial_95_177'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(73.0652 10.5167) rotate(96.6402) scale(12.456 12.391)'
      >
        <stop stopColor='#EAC12B' />
        <stop offset={0.370833} stopColor='#FFBB4C' />
        <stop offset={0.6625} stopColor='#F18914' />
        <stop offset={1} stopColor='#AC5600' />
      </radialGradient>
      <clipPath id='clip0_95_177'>
        <rect width={84.5} height={84.026} fill='white' transform='translate(0 0.002)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(BgTelegramSvgIcon);
export { Memo as BgTelegramSvgIcon };
