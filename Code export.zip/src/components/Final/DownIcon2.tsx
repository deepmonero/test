import { memo, SVGProps } from 'react';

const DownIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 54 8' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M5.28 0.847168H12L6.24 8.00011H0L5.28 0.847168Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M19.28 0.847168H26L20.24 8.00011H14L19.28 0.847168Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M33.28 0.847168H40L34.24 8.00011H28L33.28 0.847168Z' fill='#D9D9D9' stroke='#D9D9D9' />
    <path d='M47.28 0.847168H54L48.24 8.00011H42L47.28 0.847168Z' fill='#D9D9D9' stroke='#D9D9D9' />
  </svg>
);

const Memo = memo(DownIcon2);
export { Memo as DownIcon2 };
