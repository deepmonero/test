import { memo, SVGProps } from 'react';

const VectorIcon4 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 44 97' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.395782 0.954102C0.395782 24.5854 16.9862 45.9796 43.8093 61.4659V96.3766C16.9862 80.8902 0.395782 59.4961 0.395782 35.8648V0.954102Z'
      fill='#93AAFC'
    />
    <path
      d='M0.395782 0.954102C0.395782 24.5854 16.9862 45.9796 43.8093 61.4659V96.3766C16.9862 80.8902 0.395782 59.4961 0.395782 35.8648V0.954102Z'
      fill='url(#paint0_linear_95_57)'
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_57'
        x1={-0.662582}
        y1={39.4939}
        x2={44.7416}
        y2={39.7568}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#E3E1E2' />
        <stop offset={1} stopColor='#C0BAB9' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(VectorIcon4);
export { Memo as VectorIcon4 };
