import { memo, SVGProps } from 'react';

const Ellipse6Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 104 120' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M103.902 60.3137C103.902 93.2775 80.9703 120 52.6826 120C24.395 120 0.417987 92.6503 0.417987 59.6865C0.417987 26.7227 23.3497 0.000251463 51.6374 0.000251463C79.925 0.000251463 103.902 27.3499 103.902 60.3137Z'
      fill='url(#paint0_linear_95_125)'
    />
    <path
      d='M103.902 60.3137C103.902 93.2775 80.9703 120 52.6826 120C24.395 120 0.417987 92.6503 0.417987 59.6865C0.417987 26.7227 23.3497 0.000251463 51.6374 0.000251463C79.925 0.000251463 103.902 27.3499 103.902 60.3137Z'
      stroke='url(#paint1_radial_95_125)'
      strokeWidth={0.5}
    />
    <path
      d='M103.902 60.3137C103.902 93.2775 80.9703 120 52.6826 120C24.395 120 0.417987 92.6503 0.417987 59.6865C0.417987 26.7227 23.3497 0.000251463 51.6374 0.000251463C79.925 0.000251463 103.902 27.3499 103.902 60.3137Z'
      stroke='url(#paint2_linear_95_125)'
      strokeOpacity={0.05}
      strokeWidth={0.5}
    />
    <defs>
      <linearGradient
        id='paint0_linear_95_125'
        x1={105.705}
        y1={41.5956}
        x2={-29.7579}
        y2={75.1782}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#010101' stopOpacity={0} />
        <stop stopOpacity={0.9} />
        <stop offset={0.459707} stopColor='#363636' stopOpacity={0.971584} />
        <stop offset={0.827067} stopColor='#0A0A0A' stopOpacity={0.995031} />
        <stop offset={1} stopColor='#010101' />
        <stop offset={1} stopColor='white' stopOpacity={0} />
      </linearGradient>
      <radialGradient
        id='paint1_radial_95_125'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(-22.683 93.9721) rotate(-25.9442) scale(77.6512 66.964)'
      >
        <stop stopColor='#343434' />
        <stop offset={1} stopColor='#A4A4A4' stopOpacity={0} />
      </radialGradient>
      <linearGradient
        id='paint2_linear_95_125'
        x1={46.3064}
        y1={60.0001}
        x2={160.661}
        y2={111.429}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#3D3F3E' />
        <stop offset={1} stopColor='#606261' />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Ellipse6Icon3);
export { Memo as Ellipse6Icon3 };
